
# Rotich Gideon | Personal Portfolio

Welcome to my personal portfolio website! This site showcases my background in Aeronautical Engineering, technical skills, and projects.

## 🌍 Live Demo
[https://justgiddy.github.io/hackaton](https://justgiddy.github.io/hackaton)

## 🛠️ How to Use
1. Clone or download the repo.
2. Open `index.html` in your browser.

## 💡 Projects
- Aircraft Maintenance (KWS)
- AI Study Buddy Chatbot
- Budget Tracker Web App

## 📄 CV Included
- `Rotich_Gideon_Polished_CV.pdf`
